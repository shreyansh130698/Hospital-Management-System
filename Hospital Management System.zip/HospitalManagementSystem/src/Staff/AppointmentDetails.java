package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.*;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class AppointmentDetails extends JFrame {

	private JPanel contentPane;
	private JTextField txtappnum;
	private JTextField txtdtbook;
	private JTextField txtdtapp;
	private JTextField txtptname;
	private JTextField txtdate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppointmentDetails frame = new AppointmentDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AppointmentDetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAppointmentDetails = new JLabel("Appointment Details");
		lblAppointmentDetails.setForeground(Color.WHITE);
		lblAppointmentDetails.setFont(new Font("Trebuchet MS", Font.BOLD, 21));
		lblAppointmentDetails.setBounds(159, 29, 233, 38);
		contentPane.add(lblAppointmentDetails);
		
		JLabel lblappnum = new JLabel("Appointment Number");
		lblappnum.setForeground(Color.WHITE);
		lblappnum.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblappnum.setBounds(54, 101, 154, 26);
		contentPane.add(lblappnum);
		
		JLabel lbldtbook = new JLabel("Date of Booking");
		lbldtbook.setForeground(Color.WHITE);
		lbldtbook.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldtbook.setBounds(54, 153, 154, 26);
		contentPane.add(lbldtbook);
		
		JLabel lbldtapp = new JLabel("Date of Appointment");
		lbldtapp.setForeground(Color.WHITE);
		lbldtapp.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldtapp.setBounds(54, 201, 154, 26);
		contentPane.add(lbldtapp);
		
		JLabel lblptname = new JLabel("Patient's Name");
		lblptname.setForeground(Color.WHITE);
		lblptname.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblptname.setBounds(54, 248, 154, 26);
		contentPane.add(lblptname);
		
		JLabel lbldate = new JLabel("Date");
		lbldate.setForeground(Color.WHITE);
		lbldate.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldate.setBounds(54, 296, 154, 26);
		contentPane.add(lbldate);
		
		txtappnum = new JTextField();
		txtappnum.setBounds(300, 101, 259, 24);
		contentPane.add(txtappnum);
		txtappnum.setColumns(10);
		
		txtdtbook = new JTextField();
		txtdtbook.setColumns(10);
		txtdtbook.setBounds(300, 157, 259, 24);
		contentPane.add(txtdtbook);
		
		txtdtapp = new JTextField();
		txtdtapp.setColumns(10);
		txtdtapp.setBounds(300, 205, 259, 24);
		contentPane.add(txtdtapp);
		
		txtptname = new JTextField();
		txtptname.setColumns(10);
		txtptname.setBounds(300, 252, 259, 24);
		contentPane.add(txtptname);
		
		txtdate = new JTextField();
		txtdate.setColumns(10);
		txtdate.setBounds(300, 300, 259, 24);
		contentPane.add(txtdate);
		
		JButton btnback = new JButton("Back");
		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnback.setIcon(new ImageIcon(i));
		btnback.setBackground(Color.WHITE);
		btnback.setToolTipText("Return");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StaffPage sp = new StaffPage();
				sp.setVisible(true);
				contentPane.setVisible(false);
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnback.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnback.setBounds(104, 376, 104, 26);
		contentPane.add(btnback);
		
		JButton btndone = new JButton("Done");
		btndone.setBackground(Color.WHITE);
		Image i0 = new ImageIcon(this.getClass().getResource("/tck.png")).getImage();
		btndone.setIcon(new ImageIcon(i0));
		btndone.setToolTipText("Clear");
		btndone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtappnum.setText("");
				txtdtbook.setText("");
				txtdtapp.setText("");
				txtptname.setText("");
				txtdate.setText("");
			}
		});
		btndone.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btndone.setBounds(397, 376, 124, 26);
		contentPane.add(btndone);
		
		JButton btnsearch = new JButton("Search");
		btnsearch.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtdtbook.setEditable(false);
				txtdtapp.setEditable(false);
				txtptname.setEditable(false);
				txtdate.setEditable(false);
				
				String numsearch = txtappnum.getText();
				
				if(numsearch.isEmpty())
				{
					JOptionPane.showMessageDialog(contentPane,"Please Enter Appointment Number");
				}
				
			//	String query = "select * from patient_appointment where applicationNumber=?";
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = con.prepareStatement("select * from patient_appointment where applicationNumber=?");
					
					st.setString(1,numsearch);
					ResultSet rs = st.executeQuery();
					rs.next();
					
					txtappnum.setText(rs.getString(1));
					txtdtbook.setText(rs.getString(2));
					txtdtapp.setText(rs.getString(3));
					txtptname.setText(rs.getString(4));
					txtdate.setText(rs.getString(5));
					
					con.close();
				}
				catch(Exception ewq)
				{
					System.out.println(ewq);
					JOptionPane.showMessageDialog(contentPane,"Invalid Appointment Number");
				}
			}
		});
		btnsearch.setBounds(565, 101, 73, 23);
		contentPane.add(btnsearch);
		
		JLabel lblimage = new JLabel("New label");
		lblimage.setBounds(0,0,1426,717);
		contentPane.add(lblimage);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		lblimage.setIcon(new ImageIcon(img1));
	}

}
