package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class PatientAdmission extends JFrame {

	private JPanel contentPane;
	private JTextField txtid;
	private JTextField txtage;
	private JTextField txttreat;
	private JTextField txtname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PatientAdmission frame = new PatientAdmission();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PatientAdmission() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 703, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPatientAdmission = new JLabel("Patient Admission");
		lblPatientAdmission.setForeground(Color.WHITE);
		lblPatientAdmission.setFont(new Font("Trebuchet MS", Font.BOLD, 21));
		lblPatientAdmission.setBounds(131, 11, 202, 33);
		contentPane.add(lblPatientAdmission);
		
		JLabel lblPatientId = new JLabel("Patient ID");
		lblPatientId.setForeground(Color.WHITE);
		lblPatientId.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblPatientId.setBounds(30, 83, 103, 27);
		contentPane.add(lblPatientId);
		
		JLabel lblName = new JLabel("Name");
		lblName.setForeground(Color.WHITE);
		lblName.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblName.setBounds(30, 121, 103, 27);
		contentPane.add(lblName);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setForeground(Color.WHITE);
		lblAge.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAge.setBounds(30, 159, 31, 27);
		contentPane.add(lblAge);
		
		JLabel lblTreatment = new JLabel("Treatment");
		lblTreatment.setForeground(Color.WHITE);
		lblTreatment.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTreatment.setBounds(30, 197, 103, 27);
		contentPane.add(lblTreatment);
		
		JLabel lblDepartment = new JLabel("Department");
		lblDepartment.setForeground(Color.WHITE);
		lblDepartment.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDepartment.setBounds(30, 235, 103, 27);
		contentPane.add(lblDepartment);
		
		JLabel lblWard = new JLabel("Ward");
		lblWard.setForeground(Color.WHITE);
		lblWard.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblWard.setBounds(30, 273, 103, 27);
		contentPane.add(lblWard);
		
		JLabel lblFloor = new JLabel("Floor");
		lblFloor.setForeground(Color.WHITE);
		lblFloor.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblFloor.setBounds(30, 311, 103, 27);
		contentPane.add(lblFloor);
		
		JLabel lblDateOfAdmiisionn = new JLabel("Date of Admission");
		lblDateOfAdmiisionn.setForeground(Color.WHITE);
		lblDateOfAdmiisionn.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDateOfAdmiisionn.setBounds(30, 349, 119, 27);
		contentPane.add(lblDateOfAdmiisionn);
		
		JLabel lblSex = new JLabel("Sex");
		lblSex.setForeground(Color.WHITE);
		lblSex.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSex.setBounds(323, 159, 31, 27);
		contentPane.add(lblSex);
		
		txtid = new JTextField();
		txtid.setBounds(152, 87, 96, 20);
		contentPane.add(txtid);
		txtid.setColumns(10);
		
		txtage = new JTextField();
		txtage.setColumns(10);
		txtage.setBounds(152, 163, 96, 20);
		contentPane.add(txtage);
		
		txttreat = new JTextField();
		txttreat.setColumns(10);
		txttreat.setBounds(152, 201, 410, 20);
		contentPane.add(txttreat);
		
		JComboBox combodepart = new JComboBox();
		combodepart.setModel(new DefaultComboBoxModel(new String[] {"--Department--", "Department of Radiology", "Department of Cardiology", "Department of Urology", "Department of Nephrology", "Department of Oncology", "Department of Gaestrology", "Department of Medicine"}));
		combodepart.setBounds(152, 238, 219, 22);
		contentPane.add(combodepart);
		
		JComboBox comboward = new JComboBox();
		comboward.setModel(new DefaultComboBoxModel(new String[] {"--Ward--", "Private Ward", "Semi-Private Ward", "General Ward"}));
		comboward.setBounds(152, 276, 219, 22);
		contentPane.add(comboward);
		
		JComboBox combofloor = new JComboBox();
		combofloor.setModel(new DefaultComboBoxModel(new String[] {"--Floor--", "1 Floor", "2 Floor", "3 Floor", "4 Floor", "5 Floor", "6 Floor", "7 Floor", "8 Floor", "9 Floor", "10 Floor"}));
		combofloor.setBounds(152, 314, 219, 22);
		contentPane.add(combofloor);
		
		JDateChooser dc = new JDateChooser();
		dc.setBounds(152, 356, 219, 20);
		contentPane.add(dc);
		
		txtname = new JTextField();
		txtname.setColumns(10);
		txtname.setBounds(152, 125, 410, 20);
		contentPane.add(txtname);
		
		JRadioButton male = new JRadioButton("Male");
		male.setBounds(358, 162, 54, 23);
		contentPane.add(male);
		
		JRadioButton female = new JRadioButton("Female");
		female.setBounds(416, 162, 109, 23);
		contentPane.add(female);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(female);
		bg.add(male);
		
		JButton btnAdmitPatient = new JButton("Admit Patient");
		btnAdmitPatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pid = txtid.getText();
				String pname = txtname.getText();
				String page = txtage.getText();
				String gen = "";
				if(male.isSelected())
				{
					gen ="Male";
				}
				else if(female.isSelected())
				{
					gen = "Female";
				}
				String treat = txttreat.getText();
				String depart = (String)combodepart.getSelectedItem();
				String wrd = (String)comboward.getSelectedItem();
				String flr = (String)combofloor.getSelectedItem();
				SimpleDateFormat sdf = new SimpleDateFormat();
				String dt = sdf.format(dc.getDate());
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = cn.prepareStatement("insert into patient_admit(patient_id,name,age,sex,treatment,department,ward,floor,dateofaddmission) values(?,?,?,?,?,?,?,?,?)");
					
					st.setString(1, pid);
					st.setString(2, pname);
					st.setString(3, page);
					st.setString(4, gen);
					st.setString(5, treat);
					st.setString(6, depart);
					st.setString(7, wrd);
					st.setString(8, flr);
					st.setString(9, dt);
					
					st.executeUpdate();
					JOptionPane.showMessageDialog(contentPane, "Admission Done");
				}
				catch(Exception adm)
				{
					System.out.println(adm);
				}
			}
		});
		btnAdmitPatient.setToolTipText("Admit");
		btnAdmitPatient.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAdmitPatient.setBounds(416, 406, 138, 27);
		contentPane.add(btnAdmitPatient);
		
		JButton btnBack = new JButton("Back");
		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnBack.setIcon(new ImageIcon(i));
		btnBack.setBackground(Color.WHITE);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StaffPage sp = new StaffPage();
				sp.setVisible(true);
				contentPane.setVisible(false);
			}
		});
		btnBack.setToolTipText("Return");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(63, 406, 138, 27);
		contentPane.add(btnBack);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}
}
