package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Connection.*;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.border.MatteBorder;

public class StaffPage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StaffPage frame = new StaffPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StaffPage() {
		setTitle("Receptionist");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnbookapp = new JButton("Book Appointment");
		btnbookapp.setToolTipText("Book Appointment");
		btnbookapp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appointment pa = new Appointment();
				pa.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnbookapp.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btnbookapp.setBounds(60, 63, 195, 33);
		contentPane.add(btnbookapp);
		
		JButton btnappdetails = new JButton("Appointment Deatils");
		btnappdetails.setToolTipText("Appointment Details");
		btnappdetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AppointmentDetails ad = new AppointmentDetails();
				ad.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnappdetails.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btnappdetails.setBounds(60, 141, 195, 33);
		contentPane.add(btnappdetails);
		
		JButton btndocdetails = new JButton("Doctor Details");
	//	btndocdetails.setBackground(Color.WHITE);
		btndocdetails.setToolTipText("Doctor Details");
		btndocdetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowDoctor sd = new ShowDoctor();
				sd.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btndocdetails.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btndocdetails.setBounds(60, 217, 195, 33);
		contentPane.add(btndocdetails);
		
		JButton btnlogout = new JButton("");
		btnlogout.setBackground(Color.WHITE);
		Image img = new ImageIcon(this.getClass().getResource("/logout.jpg")).getImage();
		btnlogout.setIcon(new ImageIcon(img));
		btnlogout.setToolTipText("LogOut");
		btnlogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Test log = new Test();
				log.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnlogout.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btnlogout.setBounds(106, 520, 110, 33);
		contentPane.add(btnlogout);
		
		JButton btnPatientRegistration = new JButton("Patient Registration");
		btnPatientRegistration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PatientRegistration pr = new PatientRegistration();
				pr.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnPatientRegistration.setToolTipText("Patient Registration");
		btnPatientRegistration.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btnPatientRegistration.setBounds(60, 294, 195, 33);
		contentPane.add(btnPatientRegistration);
		
		JButton btnPatientAdmission = new JButton("Patient Admission");
		btnPatientAdmission.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PatientAdmission pa = new PatientAdmission();
				pa.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnPatientAdmission.setToolTipText("Patient Admission");
		btnPatientAdmission.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btnPatientAdmission.setBounds(60, 373, 195, 33);
		contentPane.add(btnPatientAdmission);
		
		JButton btnAdmissionDetails = new JButton("Admission Details");
		btnAdmissionDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdmissionDetails ad = new AdmissionDetails();
				ad.setVisible(true);
				contentPane.setVisible(false);
			}
		});
		btnAdmissionDetails.setToolTipText("Admission Details");
		btnAdmissionDetails.setFont(new Font("Kristen ITC", Font.BOLD, 13));
		btnAdmissionDetails.setBounds(60, 451, 195, 33);
		contentPane.add(btnAdmissionDetails);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0, 1426, 717);
		contentPane.add(label);
		setBounds(10,11,1416,706);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
		
	}
}
