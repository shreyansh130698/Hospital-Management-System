package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import com.toedter.calendar.JDateChooser;

public class AdmissionDetails extends JFrame {

	private JPanel contentPane;
	private JTextField txtid;
	private JTextField txtname;
	private JTextField txtage;
	private JTextField txttreat;
	private JTextField txtdepart;
	private JTextField txtward;
	private JTextField txtfloor;
	private JTextField txtdate;
	private JTextField txtsex;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdmissionDetails frame = new AdmissionDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdmissionDetails() {
		setTitle("Admission Details(Receptionist Control)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10, 11, 1416, 706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPatientAdmiisionDetails = new JLabel("Patient Admission Details");
		lblPatientAdmiisionDetails.setForeground(Color.WHITE);
		lblPatientAdmiisionDetails.setFont(new Font("Trebuchet MS", Font.BOLD, 21));
		lblPatientAdmiisionDetails.setBounds(78, 24, 276, 33);
		contentPane.add(lblPatientAdmiisionDetails);
		
		JLabel label = new JLabel("Patient ID");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Tahoma", Font.BOLD, 13));
		label.setBounds(29, 89, 103, 27);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Name");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_1.setBounds(29, 127, 103, 27);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Age");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_2.setBounds(29, 165, 31, 27);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Treatment");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_3.setBounds(29, 203, 103, 27);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Department");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_4.setBounds(29, 241, 103, 27);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("Ward");
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_5.setBounds(29, 279, 103, 27);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("Floor");
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_6.setBounds(29, 317, 103, 27);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("Date of Admission");
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_7.setBounds(29, 355, 138, 27);
		contentPane.add(label_7);
		
		JButton button = new JButton("Back");
		button.setBackground(Color.WHITE);
		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		button.setIcon(new ImageIcon(i));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StaffPage sp = new StaffPage();
				sp.setVisible(true);
				contentPane.setVisible(false);
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		button.setToolTipText("Return");
		button.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button.setBounds(56, 397, 114, 27);
		contentPane.add(button);
		
		JButton btnDone = new JButton("Done");
		btnDone.setBackground(Color.WHITE);
		Image i0 = new ImageIcon(this.getClass().getResource("/tck.png")).getImage();
		btnDone.setIcon(new ImageIcon(i0));
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtid.setText("");
				txtname.setText("");
				txtage.setText("");
				txtsex.setText("");
				txttreat.setText("");
				txtdepart.setText("");
				txtward.setText("");
				txtfloor.setText("");
				txtdate.setText("");
			}
		});
		btnDone.setToolTipText("Done");
		btnDone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDone.setBounds(342, 397, 126, 27);
		contentPane.add(btnDone);
		
		txtid = new JTextField();
		txtid.setColumns(10);
		txtid.setBounds(158, 93, 96, 20);
		contentPane.add(txtid);
		
		txtname = new JTextField();
		txtname.setColumns(10);
		txtname.setBounds(158, 134, 410, 20);
		contentPane.add(txtname);
		
		txtage = new JTextField();
		txtage.setColumns(10);
		txtage.setBounds(158, 169, 193, 20);
		contentPane.add(txtage);
		
		txttreat = new JTextField();
		txttreat.setColumns(10);
		txttreat.setBounds(158, 207, 410, 20);
		contentPane.add(txttreat);
		
		JLabel label_8 = new JLabel("Sex");
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_8.setBounds(362, 165, 31, 27);
		contentPane.add(label_8);
		
		txtdepart = new JTextField();
		txtdepart.setColumns(10);
		txtdepart.setBounds(158, 245, 193, 20);
		contentPane.add(txtdepart);
		
		txtward = new JTextField();
		txtward.setColumns(10);
		txtward.setBounds(158, 283, 193, 20);
		contentPane.add(txtward);
		
		txtfloor = new JTextField();
		txtfloor.setColumns(10);
		txtfloor.setBounds(158, 321, 193, 20);
		contentPane.add(txtfloor);
		
		txtdate = new JTextField();
		txtdate.setColumns(10);
		txtdate.setBounds(158, 359, 193, 20);
		contentPane.add(txtdate);
		
		txtsex = new JTextField();
		txtsex.setColumns(10);
		txtsex.setBounds(403, 169, 96, 20);
		contentPane.add(txtsex);
		
		JButton btnSearxh = new JButton("Search");
		btnSearxh.setToolTipText("Search Patient");
		btnSearxh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtname.setEditable(false);
				txtage.setEditable(false);
				txtsex.setEditable(false);
				txttreat.setEditable(false);
				txtdepart.setEditable(false);
				txtward.setEditable(false);
				txtfloor.setEditable(false);
				txtdate.setEditable(false);
				
				String pid = txtid.getText();
				if(pid.isEmpty())
				{
					JOptionPane.showMessageDialog(contentPane, "Please Enter Patient ID");
				}
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = cn.prepareStatement("select * from patient_admit where patient_id=?");
					
					st.setString(1,pid);
					ResultSet rs = st.executeQuery();
					rs.next();
					
					txtname.setText(rs.getString(2));
					txtage.setText(rs.getString(3));
					txtsex.setText(rs.getString(4));
					txttreat.setText(rs.getString(5));
					txtdepart.setText(rs.getString(6));
					txtward.setText(rs.getString(7));
					txtfloor.setText(rs.getString(8));
					txtdate.setText(rs.getString(9));
					
					cn.close();
				}
				catch(Exception det)
				{
					System.out.println(det);
					JOptionPane.showMessageDialog(contentPane, "Inavlid Patient ID");
				}
			}
		});
		btnSearxh.setBounds(264, 92, 87, 23);
		contentPane.add(btnSearxh);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		
		JLabel label_9 = new JLabel("");
		label_9.setBounds(0,0,1426,717);
		contentPane.add(label_9);
		Image i2 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		label_9.setIcon(new ImageIcon(i2));
	}
}
