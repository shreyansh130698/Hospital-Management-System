package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;
import com.toedter.calendar.JDateChooser;

public class Appointment extends JFrame {

	private JPanel contentPane;
	private JTextField txtappnum;
	private JTextField txtdtapp;
	private JTextField txtptname;
	private JTextField txtdate;
	private JDateChooser dcbook;
	private JTextField txtbook;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Appointment frame = new Appointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Appointment() {
		setTitle("Appointment Details(Receptionist Control)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10, 11, 1416, 706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAppointmentDetails = new JLabel("Appointment Booking");
		lblAppointmentDetails.setForeground(Color.WHITE);
		lblAppointmentDetails.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		lblAppointmentDetails.setBounds(133, 24, 209, 29);
		contentPane.add(lblAppointmentDetails);
		
		JLabel lblappnum = new JLabel("Appointment Number");
		lblappnum.setForeground(Color.WHITE);
		lblappnum.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblappnum.setBounds(33, 81, 165, 21);
		contentPane.add(lblappnum);
		
		JLabel lbldtbook = new JLabel("Date of Booking");
		lbldtbook.setForeground(Color.WHITE);
		lbldtbook.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldtbook.setBounds(33, 129, 165, 21);
		contentPane.add(lbldtbook);
		
		JLabel lbldtapp = new JLabel("Date of Appointment");
		lbldtapp.setForeground(new Color(255, 255, 255));
		lbldtapp.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldtapp.setBounds(33, 182, 165, 21);
		contentPane.add(lbldtapp);
		
		JLabel lblptname = new JLabel("Patient's Name");
		lblptname.setForeground(Color.WHITE);
		lblptname.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblptname.setBounds(33, 236, 165, 21);
		contentPane.add(lblptname);
		
		JLabel lbldate = new JLabel("Date");
		lbldate.setForeground(Color.WHITE);
		lbldate.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldate.setBounds(33, 286, 165, 21);
		contentPane.add(lbldate);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.WHITE);
		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnBack.setIcon(new ImageIcon(i));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StaffPage sp = new StaffPage();
				sp.setVisible(true);
				contentPane.setVisible(false);
			}
		});
		btnBack.setToolTipText("Click to go Back");
		btnBack.setBounds(64, 352, 110, 29);
		contentPane.add(btnBack);
		
		JButton btnDone = new JButton("Done");
		Image i0 = new ImageIcon(this.getClass().getResource("/tck.png")).getImage();
		btnDone.setIcon(new ImageIcon(i0));
		btnDone.setBackground(Color.WHITE);
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String appnum = txtappnum.getText();
				String bookdate = txtbook.getText();
				String appdate = txtdtapp.getText();
				String ptname = txtptname.getText();
				String date = txtdate.getText();
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = con.prepareStatement("insert into patient_appointment(applicationNumber,dateOfBooking,dateOfAppointment,patientName,date) values(?,?,?,?,?)");
					
					st.setString(1, appnum);
					st.setString(2, bookdate);
					st.setString(3,appdate);
					st.setString(4, ptname);
					st.setString(5, date);
					
					st.executeUpdate();
					
					JOptionPane.showMessageDialog(contentPane,"Appointment Booked Successfully");
					
					txtappnum.setText("");
					dcbook.cleanup();
					txtdtapp.setText("");
					txtptname.setText("");
					txtdate.setText("");
					
					con.close();
				}
				catch(Exception eq)
				{
					JOptionPane.showMessageDialog(contentPane,"Error in Insertion");
					System.out.println(eq);
				}
			}
		});
		btnDone.setToolTipText("Book Appointment");
		btnDone.setBounds(346, 352, 110, 29);
		contentPane.add(btnDone);
		
		txtappnum = new JTextField();
		txtappnum.setBounds(272, 81, 214, 20);
		contentPane.add(txtappnum);
		txtappnum.setColumns(10);
		
		txtdtapp = new JTextField();
		txtdtapp.setColumns(10);
		txtdtapp.setBounds(272, 183, 214, 20);
		contentPane.add(txtdtapp);
		
		txtptname = new JTextField();
		txtptname.setColumns(10);
		txtptname.setBounds(272, 237, 214, 20);
		contentPane.add(txtptname);
		
		txtdate = new JTextField();
		txtdate.setColumns(10);
		txtdate.setBounds(272, 287, 214, 20);
		contentPane.add(txtdate);
		
		txtbook = new JTextField();
		txtbook.setBounds(272, 130, 214, 20);
		contentPane.add(txtbook);
		txtbook.setColumns(10);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}
}
