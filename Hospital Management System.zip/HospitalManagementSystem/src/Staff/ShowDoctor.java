package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Color;

public class ShowDoctor extends JFrame {

	private JPanel contentPane;
	private JTextField txtdocname;
	private JTextField txtcontact;
	private JTextField txttiming;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowDoctor frame = new ShowDoctor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowDoctor() {
		setTitle("Doctor's Area");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDoctorDetails = new JLabel("Doctor Details");
		lblDoctorDetails.setForeground(Color.WHITE);
		lblDoctorDetails.setFont(new Font("Trebuchet MS", Font.BOLD, 21));
		lblDoctorDetails.setBounds(123, 27, 179, 33);
		contentPane.add(lblDoctorDetails);
		
		JLabel lbldepartment = new JLabel("Department");
		lbldepartment.setForeground(Color.WHITE);
		lbldepartment.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldepartment.setBounds(59, 98, 140, 25);
		contentPane.add(lbldepartment);
		
		JLabel lbldocname = new JLabel("Doctor's Name");
		lbldocname.setForeground(Color.WHITE);
		lbldocname.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldocname.setBounds(59, 153, 140, 25);
		contentPane.add(lbldocname);
		
		JLabel lblcontact = new JLabel("Contact");
		lblcontact.setForeground(Color.WHITE);
		lblcontact.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblcontact.setBounds(59, 199, 140, 25);
		contentPane.add(lblcontact);
		
		JLabel lbltiming = new JLabel("Timing");
		lbltiming.setForeground(Color.WHITE);
		lbltiming.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbltiming.setBounds(59, 250, 140, 25);
		contentPane.add(lbltiming);
		
		JComboBox combo = new JComboBox();
		combo.setModel(new DefaultComboBoxModel(new String[] {"--Select Department--", "Urology", "Cardiology", "Nephrology", "Radiology", "Oncology"}));
		combo.setMaximumRowCount(6);
		combo.setBounds(251, 100, 190, 22);
		contentPane.add(combo);
		
		txtdocname = new JTextField();
		txtdocname.setBounds(251, 156, 190, 20);
		contentPane.add(txtdocname);
		txtdocname.setColumns(10);
		
		txtcontact = new JTextField();
		txtcontact.setColumns(10);
		txtcontact.setBounds(251, 202, 190, 20);
		contentPane.add(txtcontact);
		
		txttiming = new JTextField();
		txttiming.setColumns(10);
		txttiming.setBounds(251, 253, 190, 20);
		contentPane.add(txttiming);
		
		JButton btngo = new JButton("Go");
		btngo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtdocname.setEditable(false);
				txtcontact.setEditable(false);
				txttiming.setEditable(false);
				
				String dep = (String)combo.getSelectedItem();
				String query = "select * from doctor where department=?";
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = con.prepareStatement(query);
					
					st.setString(1,dep);
					ResultSet rs = st.executeQuery();
					
					while(rs.next())
					{
						txtdocname.setText(rs.getString(2));
					    txtcontact.setText(rs.getString(3));
						txttiming.setText(rs.getString(4));
					}
				}
				catch(Exception ea)
				{
					System.out.println(ea);
					JOptionPane.showMessageDialog(contentPane, "Error in fetching Doctor Details");
				}
			}
		});
		btngo.setBounds(476, 100, 65, 23);
		contentPane.add(btngo);
		
		JButton btnback = new JButton("Back");
		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnback.setIcon(new ImageIcon(i));
		btnback.setBackground(Color.WHITE);
		btnback.setToolTipText("Return");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StaffPage sp = new StaffPage();
				sp.setVisible(true);
				contentPane.setVisible(false);
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnback.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnback.setBounds(98, 315, 101, 33);
		contentPane.add(btnback);
		
		JButton btndone = new JButton("Done");
		Image i0 = new ImageIcon(this.getClass().getResource("/tck.png")).getImage();
		btndone.setIcon(new ImageIcon(i0));
		btndone.setBackground(Color.WHITE);
		btndone.setToolTipText("Clear");
		btndone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				combo.setSelectedIndex(0);
				txtdocname.setText("");
				txtcontact.setText("");
				txttiming.setText("");
			}
		});
		btndone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btndone.setBounds(377, 315, 133, 33);
		contentPane.add(btndone);
		
		JButton btnShut = new JButton("Shut");
		Image i01 = new ImageIcon(this.getClass().getResource("/shut.png")).getImage();
		btnShut.setIcon(new ImageIcon(i01));
		btnShut.setBackground(Color.WHITE);
		btnShut.setToolTipText("Exit");
		btnShut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnShut.setBounds(240, 318, 101, 30);
		contentPane.add(btnShut);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}
}
