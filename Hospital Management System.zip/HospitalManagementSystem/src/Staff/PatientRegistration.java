package Staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JTextArea;
import com.toedter.calendar.JDateChooser;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class PatientRegistration extends JFrame {

	private JPanel contentPane;
	private JTextField txtid;
	private JTextField txtage;
	private JTextField txtname;
	private JTextField txtproblem;
	private JTextField txtcontact;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PatientRegistration frame = new PatientRegistration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PatientRegistration() {
		setTitle("Patient Registration");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPatientRegistration = new JLabel("Patient Registration");
		lblPatientRegistration.setForeground(Color.WHITE);
		lblPatientRegistration.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		lblPatientRegistration.setBounds(73, 11, 228, 39);
		contentPane.add(lblPatientRegistration);
		
		JLabel lblPatientId = new JLabel("Patient ID");
		lblPatientId.setForeground(Color.WHITE);
		lblPatientId.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPatientId.setBounds(32, 81, 112, 26);
		contentPane.add(lblPatientId);
		
		JLabel lblPatientName = new JLabel("Patient Name");
		lblPatientName.setForeground(Color.WHITE);
		lblPatientName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPatientName.setBounds(32, 132, 112, 26);
		contentPane.add(lblPatientName);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setForeground(Color.WHITE);
		lblAge.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAge.setBounds(32, 178, 112, 26);
		contentPane.add(lblAge);
		
		JLabel lblSex = new JLabel("Sex");
		lblSex.setForeground(Color.WHITE);
		lblSex.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblSex.setBounds(290, 178, 35, 26);
		contentPane.add(lblSex);
		
		JLabel lblContact = new JLabel("Contact");
		lblContact.setForeground(Color.WHITE);
		lblContact.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblContact.setBounds(32, 226, 112, 26);
		contentPane.add(lblContact);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setForeground(Color.WHITE);
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAddress.setBounds(32, 273, 112, 26);
		contentPane.add(lblAddress);
		
		JLabel lblProblem = new JLabel("Problem");
		lblProblem.setForeground(Color.WHITE);
		lblProblem.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblProblem.setBounds(32, 315, 112, 26);
		contentPane.add(lblProblem);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setForeground(Color.WHITE);
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDate.setBounds(32, 352, 112, 26);
		contentPane.add(lblDate);
		
		txtid = new JTextField();
		txtid.setBounds(168, 85, 96, 20);
		contentPane.add(txtid);
		txtid.setColumns(10);
		
		txtage = new JTextField();
		txtage.setColumns(10);
		txtage.setBounds(168, 182, 96, 20);
		contentPane.add(txtage);
		
		txtname = new JTextField();
		txtname.setColumns(10);
		txtname.setBounds(168, 136, 344, 20);
		contentPane.add(txtname);
		
		txtproblem = new JTextField();
		txtproblem.setColumns(10);
		txtproblem.setBounds(168, 319, 344, 20);
		contentPane.add(txtproblem);
		
		txtcontact = new JTextField();
		txtcontact.setColumns(10);
		txtcontact.setBounds(168, 230, 179, 20);
		contentPane.add(txtcontact);
		
		JTextArea txtaddress = new JTextArea();
		txtaddress.setBounds(168, 275, 344, 22);
		contentPane.add(txtaddress);
		
		JDateChooser dc = new JDateChooser();
		dc.setBounds(168, 358, 162, 20);
		contentPane.add(dc);
		
		JRadioButton rdmale = new JRadioButton("Male");
		rdmale.setBounds(331, 181, 69, 23);
		contentPane.add(rdmale);
		
		JRadioButton rdfemale = new JRadioButton("Female");
		rdfemale.setBounds(414, 181, 81, 23);
		contentPane.add(rdfemale);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rdmale);
		bg.add(rdfemale);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setToolTipText("Register Patient");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pid = txtid.getText();
				String nm = txtname.getText();
				String ag = txtage.getText();
				String gen = "";
				if(rdmale.isSelected())
				{
					gen = "Male";
				}
				else if(rdfemale.isSelected())
				{
					gen = "Female";
				}
				String con = txtcontact.getText();
				String add = txtaddress.getText();
				String prob = txtproblem.getText();
				SimpleDateFormat sdf = new SimpleDateFormat();
				String dt = sdf.format(dc.getDate());
				
		/*	if(pid.isEmpty() || nm.isEmpty() || ag.isEmpty() || gen.isEmpty() || con.isEmpty() || add.isEmpty()|| prob.isEmpty()|| dt.isEmpty() )
				{
					JOptionPane.showMessageDialog(contentPane, "All Fields are Mandatory");
				}*/
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = cn.prepareStatement("insert into patient_register(patient_id,name,age,sex,contact,address,problem,date) values(?,?,?,?,?,?,?,?)");
					
					st.setString(1, pid);
					st.setString(2, nm);
					st.setString(3, ag);
					st.setString(4, gen);
					st.setString(5, con);
					st.setString(6, add);
					st.setString(7, prob);
					st.setString(8, dt);
					
					st.executeUpdate();
					
					cn.close();
					JOptionPane.showMessageDialog(contentPane, "Registration Successfull");
						
				}
				catch(Exception dq)
				{
					System.out.println(dq);
					JOptionPane.showMessageDialog(contentPane, "Registration Failed!!");
				}
			}
		});
		btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnRegister.setBounds(402, 403, 96, 26);
		contentPane.add(btnRegister);
		
		JButton btnBack = new JButton("Back");
		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnBack.setIcon(new ImageIcon(i));
		btnBack.setBackground(Color.WHITE);
		btnBack.setToolTipText("Return");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StaffPage sp = new StaffPage();
				sp.setVisible(true);
				contentPane.setVisible(false);
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnBack.setBounds(107, 403, 96, 26);
		contentPane.add(btnBack);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg1.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}
}
