package Connection;

import javax.swing.*;

import java.awt.*;

import javax.swing.border.EmptyBorder;

import Manager.ManagerPage;
import Staff.StaffPage;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;

import com.toedter.calendar.JDateChooser;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Test extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JPasswordField txt2;
	private ResultSet rs = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test frame = new Test();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Test() {
		setBackground(Color.WHITE);
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//	setBounds(100, 100, 450, 300);
		setBounds(10,11,1416,706);
	//	setExtendedState(JFrame.MAXIMIZED_BOTH);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Image img3 = new ImageIcon(this.getClass().getResource("/usr.png")).getImage();
		
		
		txt1 = new JTextField();
		txt1.setToolTipText("Enter UserName");
		txt1.setHorizontalAlignment(SwingConstants.CENTER);
		txt1.setBounds(687, 256, 156, 20);
		contentPane.add(txt1);
		txt1.setColumns(10);
		Image img = new ImageIcon(this.getClass().getResource("/log.png")).getImage();
		
		txt2 = new JPasswordField();
		txt2.setToolTipText("Enter Password");
		txt2.setHorizontalAlignment(SwingConstants.CENTER);
		txt2.setBounds(687, 314, 156, 20);
		contentPane.add(txt2);
		Image img2 = new ImageIcon(this.getClass().getResource("/pswd.png")).getImage();
		
		JLabel lbl2 = new JLabel("Password");
		lbl2.setBounds(533, 309, 88, 29);
		contentPane.add(lbl2);
		lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2.setBackground(Color.WHITE);
		lbl2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lbl2.setIcon(new ImageIcon(img2));
		
		JLabel lbl1 = new JLabel("UserName");
		lbl1.setBounds(533, 250, 95, 30);
		contentPane.add(lbl1);
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lbl1.setIcon(new ImageIcon(img3));
		
		
		JButton btn = new JButton("Login");
		btn.setToolTipText("Click to Login");
		btn.setBounds(622, 364, 116, 31);
		contentPane.add(btn);
		btn.setBackground(Color.WHITE);
		btn.setIcon(new ImageIcon(img));
		btn.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Login", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBackground(Color.WHITE);
		panel.setBounds(476, 180, 419, 260);
		contentPane.add(panel);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		Image img1 = new ImageIcon(this.getClass().getResource("/login.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
		contentPane.add(label);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = txt1.getText();
				char[] pass = txt2.getPassword();
				String password = String.valueOf(pass);
				
				if(username.isEmpty() || password.isEmpty())
				{
					JOptionPane.showMessageDialog(contentPane,"Credentials Required");
				}
				else
				{
					String query = "select * from login where id=? and pass=?";
					
					try 
					{
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
						PreparedStatement st = con.prepareStatement(query);
						
						st.setString(1, username);
						st.setString(2, password);
						rs = st.executeQuery();
						
						if(rs.next())
						{
							String ut = rs.getString("accountrole");
							
							if(ut.equals("Manager"))
							{
								ManagerPage mp = new ManagerPage();
								mp.setVisible(true);
								this.dispose();
							}
							if(ut.equals("Staff"))
							{
								StaffPage sp = new StaffPage();
								sp.setVisible(true);
								this.dispose();
							}
						}
						else
						{
							JOptionPane.showMessageDialog(contentPane,"INVALID");
							txt2.setText("");
						}
					}
					catch(Exception ew)
					{
						System.out.println(ew);
						JOptionPane.showMessageDialog(contentPane, "Sorry");
					}
				}
				}

			private void dispose() {
				// TODO Auto-generated method stub
			}
			});
	}
}
