package Connection;

import java.sql.*;

public class CrudOperation {
	static Connection con;
	public static Connection createConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root", "root");
			System.out.println("Database Connected");
		}
		catch(SQLException se)
			{
				se.printStackTrace();
			}
		catch(ClassNotFoundException cn)
			{
				System.out.println(cn);
			}
				return con;
	}
}
