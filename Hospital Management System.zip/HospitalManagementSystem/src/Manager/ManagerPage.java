package Manager;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Manager.*;
import Connection.*;


import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;
import java.awt.SystemColor;

public class ManagerPage extends JFrame {

	private JPanel contentPane;
	JButton btncreate = null;
	JButton btnaddarea = null;
	JButton btnadddoctor = null;
	JButton btnlogout = null;
	JButton btnappointment = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerPage frame = new ManagerPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerPage() {
		setTitle("Manager Control");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//	setBounds(100, 100, 555, 451);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btncreate = new JButton("Create Account");
		btncreate.setForeground(Color.WHITE);
		btncreate.setBackground(Color.DARK_GRAY);
		btncreate.setToolTipText("Click to Create new Account");
		btncreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Account acc = new Account();
				acc.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btncreate.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		btncreate.setBounds(599, 263, 245, 48);
		contentPane.add(btncreate);
		
		JButton btnaddarea = new JButton("Add Area for Doctors");
		btnaddarea.setForeground(Color.WHITE);
		btnaddarea.setBackground(Color.DARK_GRAY);
		btnaddarea.setToolTipText("Doctor's Area");
		btnaddarea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateArea ca = new CreateArea();
				ca.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnaddarea.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		btnaddarea.setBounds(599, 345, 250, 48);
		contentPane.add(btnaddarea);
		
		JButton btnappointment = new JButton("Appointment Details");
		btnappointment.setForeground(Color.WHITE);
		btnappointment.setBackground(Color.DARK_GRAY);
		btnappointment.setToolTipText("Appointment Details");
		btnappointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CompleteAppointment ca = new CompleteAppointment();
				ca.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnappointment.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		btnappointment.setBounds(604, 426, 240, 48);
		contentPane.add(btnappointment);
		Image i0 = new ImageIcon(this.getClass().getResource("/logout.jpg")).getImage();
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(664, 525, 139, 38);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnlogout_1 = new JButton("");
		btnlogout_1.setBounds(0, 0, 139, 38);
		panel.add(btnlogout_1);
		btnlogout_1.setIcon(new ImageIcon(i0));
		btnlogout_1.setBackground(Color.DARK_GRAY);
		btnlogout_1.setToolTipText("LogOut");
		btnlogout_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Test log = new Test();
				log.setVisible(true);
				contentPane.setVisible(false);

			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnlogout_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.DARK_GRAY);
		panel_1.setForeground(Color.BLACK);
		panel_1.setBorder(new TitledBorder(null, "Manager Page", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		panel_1.setBounds(535, 177, 344, 402);
		contentPane.add(panel_1);
		
		JLabel label = new JLabel("");
		Image i = new ImageIcon(this.getClass().getResource("/bg3.jpg")).getImage();
		label.setIcon(new ImageIcon(i));
		label.setBounds(0, 0, 1426, 717);
		contentPane.add(label);
	
	}
}
