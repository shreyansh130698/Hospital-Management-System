package Manager;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class CompleteAppointment extends JFrame {

	private JPanel contentPane;
	private JTextField txtappnum;
	private JTextField txtdtbook;
	private JTextField txtdtapp;
	private JTextField txtptname;
	private JTextField txtdate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CompleteAppointment frame = new CompleteAppointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CompleteAppointment() {
		setTitle("Appointment Details(Manager Control)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAppointmentDetails = new JLabel("Appointment Details");
		lblAppointmentDetails.setForeground(Color.WHITE);
		lblAppointmentDetails.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		lblAppointmentDetails.setBounds(138, 11, 214, 41);
		contentPane.add(lblAppointmentDetails);
		
		JLabel lblappnum = new JLabel("Appointment Number");
		lblappnum.setForeground(Color.WHITE);
		lblappnum.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblappnum.setBounds(61, 97, 154, 26);
		contentPane.add(lblappnum);
		
		JLabel lbldtbook = new JLabel("Date of Booking");
		lbldtbook.setForeground(Color.WHITE);
		lbldtbook.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldtbook.setBounds(61, 147, 154, 26);
		contentPane.add(lbldtbook);
		
		JLabel lbldtapp = new JLabel("Date of Appointment");
		lbldtapp.setForeground(Color.WHITE);
		lbldtapp.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldtapp.setBounds(61, 195, 154, 26);
		contentPane.add(lbldtapp);
		
		JLabel lblptname = new JLabel("Patient's Name");
		lblptname.setForeground(Color.WHITE);
		lblptname.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblptname.setBounds(61, 251, 154, 26);
		contentPane.add(lblptname);
		
		JLabel lbldate = new JLabel("Date");
		lbldate.setForeground(Color.WHITE);
		lbldate.setFont(new Font("Tahoma", Font.BOLD, 13));
		lbldate.setBounds(61, 302, 154, 26);
		contentPane.add(lbldate);
		
		txtappnum = new JTextField();
		txtappnum.setColumns(10);
		txtappnum.setBounds(259, 101, 259, 24);
		contentPane.add(txtappnum);
		
		txtdtbook = new JTextField();
		txtdtbook.setColumns(10);
		txtdtbook.setBounds(259, 151, 259, 24);
		contentPane.add(txtdtbook);
		
		txtdtapp = new JTextField();
		txtdtapp.setColumns(10);
		txtdtapp.setBounds(259, 197, 259, 24);
		contentPane.add(txtdtapp);
		
		txtptname = new JTextField();
		txtptname.setColumns(10);
		txtptname.setBounds(259, 253, 259, 24);
		contentPane.add(txtptname);
		
		txtdate = new JTextField();
		txtdate.setColumns(10);
		txtdate.setBounds(259, 304, 259, 24);
		contentPane.add(txtdate);
		
		JButton btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtdtbook.setEditable(false);
				txtdtapp.setEditable(false);
				txtptname.setEditable(false);
				txtdate.setEditable(false);
				
				String app = txtappnum.getText();
				String dtbook = txtdtbook.getText();
				String dtapp = txtdtapp.getText();
				String ptname = txtptname.getText();
				String date = txtdate.getText();
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = con.prepareStatement("select * from patient_appointment where applicationNumber=? ");
					
					st.setString(1,app);
					ResultSet rs = st.executeQuery();
					rs.next();
					
					txtdtbook.setText(rs.getString(2));
					txtdtapp.setText(rs.getString(3));
					txtptname.setText(rs.getString(4));
					txtdate.setText(rs.getString(5));
					
					con.close();
				}
				catch(Exception ca)
				{
					System.out.println(ca);
					JOptionPane.showMessageDialog(contentPane, "Invalid Appointment Number");
				}
			}
		});
		btnsearch.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnsearch.setBounds(528, 100, 73, 23);
		contentPane.add(btnsearch);
		
		JButton btnback = new JButton("Back");

		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnback.setIcon(new ImageIcon(i));
		btnback.setBackground(Color.WHITE);
		btnback.setToolTipText("Return");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManagerPage mp = new ManagerPage();
				mp.setVisible(true);
				contentPane.setVisible(false);
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnback.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnback.setBounds(96, 363, 104, 26);
		contentPane.add(btnback);
		
		JButton btndone = new JButton("Done");
		Image i0 = new ImageIcon(this.getClass().getResource("/tck.png")).getImage();
		btndone.setIcon(new ImageIcon(i0));
		btndone.setBackground(Color.WHITE);
		btndone.setToolTipText("Done");
		btndone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtappnum.setText("");
				txtdtbook.setText("");
				txtdtapp.setText("");
				txtptname.setText("");
				txtdate.setText("");
			}
		});
		btndone.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btndone.setBounds(361, 366, 123, 26);
		contentPane.add(btndone);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg3.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}
}
