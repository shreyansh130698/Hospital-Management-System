package Manager;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Account extends JFrame {

	private JPanel contentPane;
	private JTextField txtuser;
	private JPasswordField txtpass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Account frame = new Account();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Account() {
		setTitle("Account Creation(Manager Control)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCreateAccount = new JLabel("Create Account");
		lblCreateAccount.setForeground(Color.WHITE);
		lblCreateAccount.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		lblCreateAccount.setBounds(137, 36, 198, 36);
		contentPane.add(lblCreateAccount);
		
		JLabel lbluser = new JLabel("Username");
		lbluser.setForeground(Color.WHITE);
		lbluser.setFont(new Font("Tahoma", Font.BOLD, 15));
		lbluser.setBounds(78, 126, 111, 28);
		contentPane.add(lbluser);
		
		JLabel lblpass = new JLabel("Password");
		lblpass.setForeground(Color.WHITE);
		lblpass.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblpass.setBounds(78, 193, 111, 28);
		contentPane.add(lblpass);
		
		JLabel lbldesig = new JLabel("Designation");
		lbldesig.setForeground(Color.WHITE);
		lbldesig.setFont(new Font("Tahoma", Font.BOLD, 15));
		lbldesig.setBounds(78, 250, 111, 28);
		contentPane.add(lbldesig);
		
		txtuser = new JTextField();
		txtuser.setBounds(248, 131, 227, 20);
		contentPane.add(txtuser);
		txtuser.setColumns(10);
		
		txtpass = new JPasswordField();
		txtpass.setBounds(248, 193, 227, 20);
		contentPane.add(txtpass);
		
		JComboBox combo = new JComboBox();
		combo.setModel(new DefaultComboBoxModel(new String[] {"--Designation--", "Staff", "Manager"}));
		combo.setMaximumRowCount(3);
		combo.setBounds(248, 254, 227, 22);
		contentPane.add(combo);
		
		JButton btnback = new JButton("Back");

		Image i = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		btnback.setIcon(new ImageIcon(i));
		btnback.setBackground(Color.WHITE);
		btnback.setToolTipText("Return");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManagerPage mp = new ManagerPage();
				mp.setVisible(true);
				contentPane.setVisible(false);
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnback.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnback.setBounds(100, 337, 111, 28);
		contentPane.add(btnback);
		
		JButton btncreate = new JButton("Create");
		btncreate.setBackground(Color.WHITE);
		btncreate.setToolTipText("Create Account");
		btncreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String usr = txtuser.getText();
				char[] pass = txtpass.getPassword();
				String pas = String.valueOf(pass);
				String desig = (String)combo.getSelectedItem();
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = con.prepareStatement("insert into login(id,pass,accountrole) values(?,?,?)");
					
					st.setString(1, usr);
					st.setString(2, pas);
					st.setString(3, desig);
					
					st.executeUpdate();
					con.close();
					
					JOptionPane.showMessageDialog(contentPane, "Account Sucessfully Created");
				}
				catch(Exception desi)
				{
					System.out.println(desi);
					JOptionPane.showMessageDialog(contentPane, "Error in Account Creation");
				}
			}
		});
		btncreate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btncreate.setBounds(348, 337, 89, 28);
		contentPane.add(btncreate);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg3.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}

}
