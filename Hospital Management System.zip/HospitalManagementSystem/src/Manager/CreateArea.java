package Manager;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class CreateArea extends JFrame {

	private JPanel contentPane;
	private JTextField txtdep;
	private JTextField txtfloor;
	private JTextField txtcabin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateArea frame = new CreateArea();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateArea() {
		setTitle("Doctor's Area(Manager Control)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10,11,1416,706);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDoctorsArea = new JLabel("Doctor's Area");
		lblDoctorsArea.setForeground(Color.WHITE);
		lblDoctorsArea.setFont(new Font("Trebuchet MS", Font.BOLD, 21));
		lblDoctorsArea.setBounds(204, 11, 180, 43);
		contentPane.add(lblDoctorsArea);
		
		JLabel lblDoctorName = new JLabel("Doctor Name");
		lblDoctorName.setForeground(Color.WHITE);
		lblDoctorName.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDoctorName.setBounds(103, 95, 129, 29);
		contentPane.add(lblDoctorName);
		
		JLabel lblDepartment = new JLabel("Department");
		lblDepartment.setForeground(Color.WHITE);
		lblDepartment.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDepartment.setBounds(103, 143, 129, 29);
		contentPane.add(lblDepartment);
		
		JLabel lblFloorNumber = new JLabel("Floor Number");
		lblFloorNumber.setForeground(Color.WHITE);
		lblFloorNumber.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblFloorNumber.setBounds(103, 190, 129, 29);
		contentPane.add(lblFloorNumber);
		
		JLabel lblCabinNumber = new JLabel("Cabin Number");
		lblCabinNumber.setForeground(Color.WHITE);
		lblCabinNumber.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblCabinNumber.setBounds(103, 238, 129, 29);
		contentPane.add(lblCabinNumber);
		
		JComboBox combo = new JComboBox();
		combo.setModel(new DefaultComboBoxModel(new String[] {"--Doctor's Name--", "Dr. Satyam", "Dr. Prabhat", "Dr. Ranjeet", "Dr. Abdul", "Dr. Tushant"}));
		combo.setMaximumRowCount(6);
		combo.setBounds(360, 99, 193, 22);
		contentPane.add(combo);
		
		txtdep = new JTextField();
		txtdep.setBounds(362, 148, 191, 20);
		contentPane.add(txtdep);
		txtdep.setColumns(10);
		
		txtfloor = new JTextField();
		txtfloor.setColumns(10);
		txtfloor.setBounds(360, 195, 191, 20);
		contentPane.add(txtfloor);
		
		txtcabin = new JTextField();
		txtcabin.setColumns(10);
		txtcabin.setBounds(360, 243, 191, 20);
		contentPane.add(txtcabin);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setToolTipText("Go");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String doc = (String)combo.getSelectedItem();
				String depart = txtdep.getText();
				String floor = txtfloor.getText();
				String cabin = txtcabin.getText();
				
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
					PreparedStatement st = con.prepareStatement("select * from area where name=?");
					
					st.setString(1, doc);
					
					ResultSet rs = st.executeQuery();
					
					while(rs.next())
					{
						txtdep.setText(rs.getString(2));
						txtfloor.setText(rs.getString(3));
						txtcabin.setText(rs.getString(4));
					}
				}
				catch(Exception doct)
				{
					System.out.println(doct);
					JOptionPane.showMessageDialog(contentPane, "Error in Searching");
				}
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSearch.setBounds(234, 295, 99, 35);
		contentPane.add(btnSearch);
		
		JLabel label = new JLabel("");
		label.setBounds(0,0,1426,717);
		contentPane.add(label);
		Image img1 = new ImageIcon(this.getClass().getResource("/bg3.jpg")).getImage();
		label.setIcon(new ImageIcon(img1));
	}

}
