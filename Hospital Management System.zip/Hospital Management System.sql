-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.18-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema `database`
--

CREATE DATABASE IF NOT EXISTS `database`;
USE `database`;

--
-- Definition of table `area`
--

DROP TABLE IF EXISTS `area`;
CREATE TABLE `area` (
  `name` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  `floor` varchar(45) NOT NULL,
  `cabin` varchar(45) NOT NULL,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` (`name`,`department`,`floor`,`cabin`) VALUES 
 ('Dr. Abdul','Nephrology','3','06'),
 ('Dr. Prabhat','Cardiology','2','05'),
 ('Dr. Ranjeet','Oncology','4','10'),
 ('Dr. Satyam','Urology','4','12'),
 ('Dr. Tushant','Radiology','2','02');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;


--
-- Definition of table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor` (
  `department` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `timing` varchar(45) NOT NULL,
  PRIMARY KEY  (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` (`department`,`name`,`contact`,`timing`) VALUES 
 ('Cardiology','Dr. Prabhat','256398741','9AM - 2PM'),
 ('Nephrology','Dr. Abdul','789654123','9AM - 1PM'),
 ('Oncology','Dr. Ranjeet','987456321','2PM - 8PM'),
 ('Radiology','Dr. Tushant','456987123','12PM - 4PM'),
 ('Urology','Dr. Satyam','896574123','10AM - 2PM');
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `id` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `accountrole` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`id`,`pass`,`accountrole`) VALUES 
 ('','',''),
 ('Honey','honey','Manager'),
 ('shrey','ansh','Staff'),
 ('Shreyan','de','Staff'),
 ('shreyansh','devil','Manager');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `patient_admit`
--

DROP TABLE IF EXISTS `patient_admit`;
CREATE TABLE `patient_admit` (
  `patient_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `age` int(10) unsigned NOT NULL,
  `sex` varchar(45) NOT NULL,
  `treatment` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  `ward` varchar(45) NOT NULL,
  `floor` varchar(45) NOT NULL,
  `dateofaddmission` varchar(45) NOT NULL,
  PRIMARY KEY  (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_admit`
--

/*!40000 ALTER TABLE `patient_admit` DISABLE KEYS */;
INSERT INTO `patient_admit` (`patient_id`,`name`,`age`,`sex`,`treatment`,`department`,`ward`,`floor`,`dateofaddmission`) VALUES 
 (59123,'Rajeev Lochan Srivastava',69,'Male','PCN','Department of Radiology','Private Ward','6 Floor','04/06/19, 5:57 PM'),
 (59424,'Rajni Saxena',45,'Male','Cancer','Department of Oncology','Semi-Private Ward','5 Floor','01/06/19, 6:06 PM');
/*!40000 ALTER TABLE `patient_admit` ENABLE KEYS */;


--
-- Definition of table `patient_appointment`
--

DROP TABLE IF EXISTS `patient_appointment`;
CREATE TABLE `patient_appointment` (
  `applicationNumber` int(10) unsigned NOT NULL auto_increment,
  `dateOfBooking` varchar(45) NOT NULL,
  `dateOfAppointment` varchar(45) NOT NULL,
  `patientName` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  PRIMARY KEY  (`applicationNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_appointment`
--

/*!40000 ALTER TABLE `patient_appointment` DISABLE KEYS */;
INSERT INTO `patient_appointment` (`applicationNumber`,`dateOfBooking`,`dateOfAppointment`,`patientName`,`date`) VALUES 
 (123,'30-05-2019','10-06-2019','Anil Apte','30-05-2019'),
 (129,'23-05-2019','15-06-2019','Raju','30-05-2019'),
 (420,'04-02-2020','06-06-2020','Cheedur','30-05-2019'),
 (1234,'10-06-2019','26-06-2019','Sanjeevni Shukla','10-06-2019'),
 (132132,'12','98','chotu','12'),
 (716629,'01-06-2019','13-06-2019','Devil','01-06-2019');
/*!40000 ALTER TABLE `patient_appointment` ENABLE KEYS */;


--
-- Definition of table `patient_register`
--

DROP TABLE IF EXISTS `patient_register`;
CREATE TABLE `patient_register` (
  `patient_id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `age` int(10) unsigned NOT NULL,
  `sex` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `problem` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  PRIMARY KEY  (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_register`
--

/*!40000 ALTER TABLE `patient_register` DISABLE KEYS */;
INSERT INTO `patient_register` (`patient_id`,`name`,`age`,`sex`,`contact`,`address`,`problem`,`date`) VALUES 
 (25423,'Datta Rai',54,'Male','5236987412','25/65,Indira Nagar,Lucknow','Bladder','01/06/19, 4:17 PM'),
 (49523,'Rajeev Lochan Srivastava',69,'Male','9936782569','17/854,Gandhi Nagar,Agra','Prostate Cancer','04/06/19, 4:08 PM'),
 (655321,'NISHANT',45,'Female','7007408038','2/94','HEART ATTACK','30/06/19, 12:00 AM');
/*!40000 ALTER TABLE `patient_register` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
